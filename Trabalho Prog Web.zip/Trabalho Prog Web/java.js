
if (localStorage.estado)
					{
						document.getElementById('estado').value = localStorage.estado;
					}
					if (localStorage.dataInicio)
					{
						document.getElementById('dataInicio').value = localStorage.dataInicio;
					}
					if (localStorage.dataFinal)
					{
						document.getElementById('dataFinal').value = localStorage.dataFinal;
					}
					
					var salvarData = function()
					{
						var estado = document.getElementById('estado').value;
						var dataInicio = document.getElementById('dataInicio').value;
						var dataFinal = document.getElementById('dataFinal').value;

						localStorage.setItem('estado', estado);
						localStorage.setItem('dataInicio', dataInicio);
						localStorage.setItem('dataFinal', dataFinal);
					};
					
					document.onchange = salvarData;
                    